# Fetch PubMed Papers

## Overview
This tool fetches research papers from PubMed based on a user-specified query, filters papers with at least one author affiliated with a pharmaceutical or biotech company, and outputs the results in CSV format.

## Features
- Fetches research papers from PubMed using the Entrez API.
- Filters authors based on non-academic affiliations.
- Outputs results as a CSV file or prints them to the console.
- Supports command-line options for debugging and specifying output files.

## Installation

### Prerequisites
- Python 3.8+
- [Poetry](https://python-poetry.org/docs/#installation)

### Setup
```sh
# Clone the repository
git clone https://github.com/yourusername/fetch-pubmed-papers.git
cd fetch-pubmed-papers

# Install dependencies
poetry install
```

## Usage
Run the following command to fetch papers:
```sh
poetry run get-papers-list "cancer treatment" -f results.csv
```
Options:
- `-f, --file`: Specify a CSV filename to save the results.
- `-d, --debug`: Enable debug mode.
- `-h, --help`: Show usage instructions.

## Project Structure
```
fetch_pubmed_papers/
│── fetch_papers.py  # Main script for fetching papers
│── README.md        # Documentation
│── pyproject.toml   # Poetry dependency file
│── tests/           # Unit tests
```

## Publishing to TestPyPI (Bonus)
To publish the module:
```sh
poetry build
poetry publish -r testpypi
```

## License
MIT License
